# Autonomous Racing Systems

## Working scope

- Current user priority (2026-09-29): CAD, FEA and building. Start with
  [the CAD/FEA and wiring handoff](docs/CAD_FEA_BUILD_AND_WIRING_2026-09-29.txt).
  Purchased measurement boards support a modular harness; no custom PCB is
  required for the first build. The handoff includes core and optional wiring.
- In this user's workflow, Codex prepares plans and detailed `.txt` handoffs;
  Claude implements them. Keep Codex work to planning unless the user explicitly
  changes that scope.
- The current handoff is [the September 19–25 plan](docs/WEEK_PLAN_2026-09-19_TO_25.txt).
  Inspect current branches and evidence before planning work that may already exist.
- For remaining work, start with [the September 25 closeout handoff](docs/CLOSEOUT_PLAN_2026-09-25.txt).
  It updates the weekly plan and critique against merged PR #40 corrections.
- Read the [September 24 literature critique](docs/LITERATURE_CRITIQUE_2026-09-24.txt)
  before extending E3, W3.1 or the mast modal model. It identifies reproduced
  decision-logic failures and proposed uncertainty/model-verification corrections.

## CAD and FEA context

- Read `500ft/engineering-audit → docs/cad_agent_briefing.md` before CAD/FEA
  planning. Read that repo's `docs/host_setup.md` for host work and
  `docs/solidworks_api_findings.md` before proposing COM changes.
- [Shared CAD workflow decision](docs/decisions/0001-shared-cad-workflow.md)
  records the reviewed source revision, repo ownership, branch context and
  project consequences. Refresh the references when they change.
- Reusable host/CAD/FEA machinery belongs in `engineering-audit`; RoboRacer
  geometry, contracts and project evidence belong here.
- Preserve `cad/generate.py` and `cad/contract.json` for the frozen 100 mm
  analysis specimen. Native assembly-part work uses `cad/solidworks/` and its
  separate contract. A directory name does not establish an assembly document.
- Acceptance needs independent geometry checks, a parameter-change test and
  export round-trip evidence. A clean rebuild or solver exit alone does not
  establish correctness. CI oracle checks do not establish host runs.
- Respect parameter acquisition routes. Keep provisional design choices separate
  from measured inputs. Instrument purchases do not establish calibration or
  physical campaign readiness.

## Planning context recorded 2026-09-21

- Equipment-specific force logging/calibration preparation remains the weekly
  priority; displacement/root-motion and fixture evidence remain gaps.
- Native tube-stock, support-sleeve and clamp work was found on
  `cad/solidworks-mast-assembly`; equipment intake on `week/day1-20260919`.
  Inspect these branches before duplicating work or assuming it is on main.
- Assembly mates, fully driven feature positions, drawings and independent FEA
  checks are the next CAD/FEA questions. They do not displace the core acquisition
  work or automatically close existing physical gates.

## Latest review snapshot, 2026-09-24

- Main `7080248` contains native CAD parts, acquisition software, E3 calibration
  and the literature folder. W3.1 was inspected separately at `02e119d` on
  `task/w31-fixture-feasibility-20260923`. Refresh refs before implementation.
- Prioritize calibration verdicts and fixture gates, then correlated uncertainty
  and the modal mass-connection audit. The critique records synthetic evidence;
  code corrections and physical protocol amendments have not been implemented
  by this planning session.

## Latest review snapshot, 2026-09-25

- Main inspected at `fb7379f`; PR #41 was open and green at `4a52b14`.
  Refresh before implementation. Older critique counterexamples are historical;
  check current code before assuming a defect remains.
- Current-source synthetic sensitivity: 0.3 micrometre assumed repeatability
  gives about 86% single-axis R² pass frequency, despite its passing median.
  A median screen is not a joint campaign pass probability or hardware evidence.
- Closeout priorities: consistency, W3.2 decision/input packet, bounded modal
  attachment comparison, scoped W1.8, then W4 evidence freeze. A/B/C modal cases
  separate attachment representation from mass position. Preserve legacy output.
- A protocol amendment remains prospective. Installed repeatability, resolution,
  bias and uncertainty are distinct. W4 review readiness does not close physical
  gates or establish independent review. Codex only updated planning artifacts.

## Latest review snapshot, 2026-09-29

- Main inspected at `dbcff01`. Three native parts exist; the assembly run is
  PARTIAL because placement is wrong and component volume checks are missing.
  Fix placement, mates and reopened-file geometry before assembly FEA.
- The modal attachment comparison exists: 285.5111 / 316.8406 / 320.8747 Hz
  for legacy / coupled eccentric / coupled centred, on one mesh. New headline
  adoption still needs refinement evidence. Do not redo this as unstarted work.
- Host dimension-input toggle and clamp width/height/engagement re-drive have
  evidence. Slot/bolt positions and remaining mechanical interfaces need work.
- Electronics are purchased modules. Core NAU7802 uses QT Py STEMMA I2C;
  optional LIS3DH/INA260 harness uses the separate header bus. Wiring is proposed,
  not device-tested. Planning-only scope remains in place for Codex.
