import sys, json, os, traceback
import pythoncom, win32com.client
out = {}
wd = sys.argv[1]
P = r"C:\Users\admin\Desktop\Projects\autonomous-racing-systems\root_clamp.SLDPRT"
sw = win32com.client.Dispatch("SldWorks.Application")
sw.Visible = False
def T(label, f):
    try: out[label] = repr(f())[:200]
    except Exception as e: out[label] = "ERR " + repr(e)[:150]
try:
    a = sw.NewDocument(r"C:\ProgramData\SolidWorks\SOLIDWORKS 2024\templates\Assembly.ASMDOT", 0, 0, 0)
    a = sw.ActiveDoc
    ea = win32com.client.VARIANT(pythoncom.VT_I4|pythoncom.VT_BYREF, 0); wa = win32com.client.VARIANT(pythoncom.VT_I4|pythoncom.VT_BYREF, 0)
    sw.OpenDoc6(P, 1, 1, "", ea, wa)
    act = win32com.client.VARIANT(pythoncom.VT_I4|pythoncom.VT_BYREF, 0)
    sw.ActivateDoc3(a.GetTitle, False, 0, act)
    c = a.AddComponent4(P, "", 0, 0, 0)
    out["comp"] = repr(c)
    mt = c.Transform2
    out["arr0"] = list(mt.ArrayData)
    mu = sw.GetMathUtility
    arr = [1.0,0,0,0,1.0,0,0,0,1.0,-0.022,-0.022,0.0,1.0,0,0,0]
    T("ids", lambda: [mu._oleobj_.GetIDsOfNames(n) for n in ("CreateTransform","CreatePoint")])
    def s0():
        d = mu._oleobj_.GetIDsOfNames("CreateTransform")[0]
        r = mu._oleobj_.Invoke(d, 0, pythoncom.DISPATCH_METHOD, 1, arr)
        return list(win32com.client.Dispatch(r).ArrayData)
    T("invoke_CreateTransform", s0)
    def s1():
        mt.ArrayData = win32com.client.VARIANT(pythoncom.VT_ARRAY|pythoncom.VT_R8, arr); return list(mt.ArrayData)
    T("set_ArrayData_variant", s1)
    def s3():
        d = mt._oleobj_.GetIDsOfNames("ArrayData")[0]
        mt._oleobj_.Invoke(d, 0, pythoncom.DISPATCH_PROPERTYPUT, 0, win32com.client.VARIANT(pythoncom.VT_ARRAY|pythoncom.VT_R8, arr)); return list(mt.ArrayData)
    T("put_ArrayData_invoke", s3)
    def s4():
        c.Transform2 = mt; return list(c.Transform2.ArrayData)
    T("set_Transform2_after", s4)
except Exception:
    out["exc"] = traceback.format_exc()
try: sw.ExitApp()
except Exception: pass
json.dump(out, open(os.path.join(wd, "probe_mu.json"), "w"), indent=1)
