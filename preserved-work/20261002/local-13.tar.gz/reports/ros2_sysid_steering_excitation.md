# ROS 2 SysID Steering Excitation

This run ports the existing Gym SysID excitation workflow into ROS 2.
It collects excitation data only; no parameter fitting is performed.

Environment command signals are not internal dynamic-model inputs.
`command_steer_rad` and `command_speed_mps` are published setpoints; 
`steer_vel_radps` and `accel_x_mps2` are reconstructed from achieved state.

Quality status: `passed`.

Fitting starts only after excitation quality passes.
